import React from 'react';
import { UserProfile, RiskLevel, FinancialGoal } from '../types';

interface ProfileFormProps {
  profile: UserProfile;
  onChange: (field: keyof UserProfile, value: string | number | RiskLevel | FinancialGoal) => void;
}

export const ProfileForm: React.FC<ProfileFormProps> = ({ profile, onChange }) => {
  const inputClass = "w-full mt-1 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-colors bg-white";
  const labelClass = "block text-sm font-medium text-gray-700 mt-4";

  return (
    <div className="animate-fade-in-up">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Basic Financial Profile</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-2">
        <div>
          <label className={labelClass}>Age</label>
          <input
            type="number"
            min="18"
            max="100"
            value={profile.age || ''}
            onChange={(e) => onChange('age', parseInt(e.target.value) || 0)}
            className={inputClass}
            placeholder="e.g. 28"
          />
        </div>

        <div>
          <label className={labelClass}>Monthly Income (₹)</label>
          <input
            type="number"
            min="0"
            value={profile.monthlyIncome || ''}
            onChange={(e) => onChange('monthlyIncome', parseInt(e.target.value) || 0)}
            className={inputClass}
            placeholder="e.g. 80000"
          />
        </div>

        <div>
          <label className={labelClass}>Monthly Expenses (₹)</label>
          <input
            type="number"
            min="0"
            value={profile.monthlyExpenses || ''}
            onChange={(e) => onChange('monthlyExpenses', parseInt(e.target.value) || 0)}
            className={inputClass}
            placeholder="e.g. 35000"
          />
        </div>

        <div>
          <label className={labelClass}>Current Savings (₹)</label>
          <input
            type="number"
            min="0"
            value={profile.currentSavings || ''}
            onChange={(e) => onChange('currentSavings', parseInt(e.target.value) || 0)}
            className={inputClass}
            placeholder="e.g. 200000"
          />
        </div>

        <div>
          <label className={labelClass}>Risk Level</label>
          <div className="mt-1 grid grid-cols-3 gap-2">
            {Object.values(RiskLevel).map((level) => (
              <button
                key={level}
                type="button"
                onClick={() => onChange('riskLevel', level)}
                className={`p-2 rounded-md text-sm font-medium border transition-all ${
                  profile.riskLevel === level
                    ? 'bg-indigo-600 text-white border-indigo-600 shadow-md'
                    : 'bg-white text-gray-600 border-gray-300 hover:bg-gray-50'
                }`}
              >
                {level}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className={labelClass}>Primary Goal</label>
          <select
            value={profile.financialGoal}
            onChange={(e) => onChange('financialGoal', e.target.value as FinancialGoal)}
            className={inputClass}
          >
            {Object.values(FinancialGoal).map((goal) => (
              <option key={goal} value={goal}>
                {goal}
              </option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
};