import React from 'react';

interface StepIndicatorProps {
  currentStep: number;
  totalSteps: number;
}

export const StepIndicator: React.FC<StepIndicatorProps> = ({ currentStep, totalSteps }) => {
  return (
    <div className="w-full mb-8">
      <div className="flex justify-between mb-2">
        {Array.from({ length: totalSteps }).map((_, index) => {
            const stepNum = index + 1;
            const isActive = stepNum <= currentStep;
            return (
                <div key={index} className={`flex flex-col items-center w-1/3 ${index === 0 ? 'items-start' : index === totalSteps - 1 ? 'items-end' : ''}`}>
                    <span className={`text-xs font-semibold uppercase tracking-wider ${isActive ? 'text-indigo-600' : 'text-gray-400'}`}>
                        {index === 0 ? 'Profile' : index === 1 ? 'Interests' : 'Advice'}
                    </span>
                </div>
            )
        })}
      </div>
      <div className="h-2 bg-gray-200 rounded-full overflow-hidden flex">
        {Array.from({ length: totalSteps }).map((_, index) => {
          const stepNum = index + 1;
          return (
            <div
              key={index}
              className={`h-full transition-all duration-500 ease-out flex-1 ${
                stepNum <= currentStep ? 'bg-indigo-600' : 'bg-transparent'
              }`}
            />
          );
        })}
      </div>
    </div>
  );
};