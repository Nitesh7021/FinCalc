import React from 'react';
import { FinancialField } from '../types';

interface FieldSelectorProps {
  selectedFields: FinancialField[];
  toggleField: (field: FinancialField) => void;
}

export const FieldSelector: React.FC<FieldSelectorProps> = ({ selectedFields, toggleField }) => {
  return (
    <div className="animate-fade-in-up">
      <h2 className="text-2xl font-bold text-gray-900 mb-2">What do you want advice on?</h2>
      <p className="text-gray-500 mb-6">Select one or more topics to get personalized suggestions.</p>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {Object.values(FinancialField).map((field) => {
          const isSelected = selectedFields.includes(field);
          return (
            <button
              key={field}
              onClick={() => toggleField(field)}
              className={`relative p-4 rounded-xl border-2 text-left transition-all duration-200 group ${
                isSelected
                  ? 'border-indigo-600 bg-indigo-50 shadow-md'
                  : 'border-gray-200 bg-white hover:border-indigo-300 hover:bg-gray-50'
              }`}
            >
              <div className="flex justify-between items-center">
                <span className={`font-semibold ${isSelected ? 'text-indigo-700' : 'text-gray-700'}`}>
                  {field}
                </span>
                {isSelected && (
                  <svg className="w-5 h-5 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                )}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};