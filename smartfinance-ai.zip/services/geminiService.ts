import { GoogleGenAI, Type } from "@google/genai";
import { UserProfile, FinancialField, AnalysisResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateFinancialAdvice = async (
  profile: UserProfile,
  selectedFields: FinancialField[]
): Promise<AnalysisResult> => {
  const modelId = "gemini-3-flash-preview";

  const prompt = `
    Analyze the following user financial profile and provide specific suggestions for the selected fields.
    
    User Profile:
    - Age: ${profile.age}
    - Monthly Income: ${profile.monthlyIncome}
    - Monthly Expenses: ${profile.monthlyExpenses}
    - Current Savings: ${profile.currentSavings}
    - Risk Level: ${profile.riskLevel}
    - Primary Goal: ${profile.financialGoal}

    Selected Fields for Advice: ${selectedFields.join(", ")}

    Apply the following logic rules rigidly where applicable:
    
    1. **Mutual Funds**: 
       - If Risk Low -> Suggest Debt/Hybrid.
       - If Risk High -> Suggest Equity/Index.
       - Check Expense Ratio importance.
    2. **Stocks**:
       - If Income is low relative to expenses -> Advise avoiding high volatility.
       - Suggest allocation % (e.g., 10-20%).
       - Warn about over-concentration.
    3. **SIP**:
       - Rule: Ideally 15-20% of income. Calculate current capacity.
       - Highlight gap between current potential and goal.
    4. **Loans / EMI**:
       - Risk Alert if EMI potential (Income - Expenses) is tight.
       - Suggest prepayment or tenure optimization.
    5. **Taxes**:
       - Suggest saving sections (80C, etc).
       - Mention Old vs New regime based on income level.
    6. **Insurance**:
       - Life cover rule: 10-15x annual income.
       - Health insurance check.
    7. **Emergency Fund**:
       - RED ALERT if Current Savings < 6 * Monthly Expenses.
    8. **Retirement**:
       - Project need for future corpus based on age.

    Output valid JSON strictly adhering to the schema.
  `;

  try {
    const response = await ai.models.generateContent({
      model: modelId,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            overview: {
              type: Type.STRING,
              description: "A brief 2-sentence summary of their financial health.",
            },
            suggestions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  field: { type: Type.STRING },
                  status: { type: Type.STRING, enum: ["Good", "Warning", "Alert"] },
                  title: { type: Type.STRING },
                  content: { type: Type.STRING },
                  actionItem: { type: Type.STRING },
                },
                required: ["field", "status", "title", "content", "actionItem"],
              },
            },
          },
          required: ["overview", "suggestions"],
        },
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    
    return JSON.parse(text) as AnalysisResult;
  } catch (error) {
    console.error("Gemini API Error:", error);
    // Fallback mock response in case of API failure to prevent app crash
    return {
        overview: "We encountered an issue connecting to the financial advisor AI. Please try again.",
        suggestions: []
    };
  }
};